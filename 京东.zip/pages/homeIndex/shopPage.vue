<template>
	<view class="shopPageBox">
		<!-- 顶部返回按钮 -->
		<view class="navLogo">
			<u-icon 
				class="navLogoLeft" 
				name="arrow-left" 
				size="46"
				@click="backPage">
			</u-icon>
			<u-icon class="navLogoRight" name="more-dot-fill" size="46"></u-icon>
		</view>
		
		<!-- 轮播图 -->
		<swiper 
			@change="changSwiper"
			class="swiper"
			interval="3000">
			<swiper-item
				class="swiper-item"
				v-for="(item,index) in swiperlist"
				:key="item.id">
				<image class="swiperImage" mode="aspectFill"
					:src="item.image"></image>
			</swiper-item>
		</swiper>
		<view class="showNum">{{showNum}}/{{swiperlist.length}}</view>
		<image class="logo618" src="../../static/image/logo618.png" mode="aspectFill"></image>
		
		<!-- 商品详情内容 -->
		<view class="shopPrice">
			<view class="shopPriceLeft">
				<view class="rmb">￥</view>
				<view class="rmbPrice">2998</view>
				<view class="rmbFloat">.00</view>
			</view>
			<view class="shopPriceRight">
				<view>
					<u-icon name="rmb" size="30"></u-icon>
					<view class="remind1">降价提醒</view>
				</view>
				<view>
					<u-icon name="heart" size="30"></u-icon>
					<view class="remind2">收藏</view>
				</view>
			</view>
		</view>
		
		<!-- 商品标题 -->
		<view class="shopBigTitleMsg">
			<view class="shopBigTitle">
				<view><text class="shopWay">自营</text>松下(Panasonic) GF10K 微单相机数码相机vlog相机微单套(12-32mm) 4K视频美颜自拍粉色</view>
			</view>
			<view class="shopBigTitleBottom">
				6.18惊喜驾到! 开门红31日晚8点-3日直降400! 更多好物请戳<text>查看></text>
			</view>
		</view>
		
		<view class="kongDiv">
		</view>
		
		<!-- 优惠 -->
		<view class="youHui">
			<view class="youHuiMsg">
				<text>优惠</text>
				<text>限购</text>
				购买1-100件时享受单件价￥2998,超出数量以结算
				价为准，仅限购买一次
			</view>
		</view>
		
		<view class="kongDiv">
		</view>
		
		<!-- 已选 -->
		<view class="yiXuan">
			<view class="yiXuanLeft">
				已选
			</view>
			<view class="yiXuanRight">
				<view>粉色(标准镜头12-32mm),1个</view>
				<view>本商品支持京选服务、京东保障服务、京东服务+,点击可选服务</view>
			</view>
		</view>
		<!-- 送至 -->
		<view class="songZhi">
			<view class="songZhiLeft">
				送至
			</view>
			<view class="songZhiRight">
				<view>北京朝阳区三环到四环之间</view>
				<view>
					<image
						class="songZhiImage"
						src="../../static/image/songZhilogo.png" 
						mode="aspectFill">
					</image>
					<text class="songZhiXianhuo">现货</text>
					23:00前下单,预计明天(05月25日)送达
				</view>
			</view>
		</view>
		
		<!-- 重量 -->
		<view class="shopWeight">
			<view>重量</view>
			<view>0.61kg</view>
		</view>
		
		
		<!-- 更多信息 -->
		<view class="someMsg">
			<view class="someMsgTop">
				<u-icon class="someIcon" name="checkbox-mark" color="#fc3f2d" size="15"></u-icon>
				<view class="someFont">京东发货&善后</view>
			</view>
			<view class="someMsgConetent">
				<view class="someMsgItem">
					<u-icon class="someIcon" name="info" color="#999" size="15"></u-icon>
					<view class="someFont">7天无理由退货(一次性包装破损不支持)</view>
				</view>
				<view class="someMsgItem">
					<u-icon class="someIcon" name="checkbox-mark" color="#fc3f2d" size="15"></u-icon>
					<view class="someFont">次日达</view>
				</view>
			</view>
			<view class="someMsgBottom">
				<view class="someMsgItem">
					<u-icon class="someIcon" name="checkbox-mark" color="#fc3f2d" size="15"></u-icon>
					<view class="someFont">预约送货</view>
				</view>
				<view class="someMsgItem">
					<u-icon class="someIcon" name="checkbox-mark" color="#fc3f2d" size="15"></u-icon>
					<view class="someFont">部分收货</view>
				</view>
				<view class="someMsgItem">
					<u-icon class="someIcon" name="checkbox-mark" color="#fc3f2d" size="15"></u-icon>
					<view class="someFont">包邮</view>
				</view>
				<view class="someMsgItem">
					<u-icon class="someIcon" name="checkbox-mark" color="#fc3f2d" size="15"></u-icon>
					<view class="someFont">30天价保</view>
				</view>
			</view>
		</view>
		
		<view class="kongDiv">
		</view>
		
		<!-- 评论内容 -->
		<view class="pingBox">
			<view class="pingTop">
				<view class="pinglun">评论 <text class="pingNum">5000+</text></view>
				<view class="pingTopRight">
					<view class="haoping">好评度 94%</view>
					<u-icon name="arrow-right" size="30"></u-icon>
				</view>
			</view>
			<view class="pingModule">
				<view
				class="pingModuleItem"
				v-for="(item,index) in pingModulelist"
				:key="item.id">
					{{item.content}}
				</view>
			</view>
			
			<!-- 评论详情 -->
			<view class="pinglunMsg"
			v-for="(item,index) in pinglist"
			:key="item.id">
				<view class="pinglunTop">
					<view class="pinglunTopLeft">
						<image class="pinglunImage" :src="item.image" mode="aspectFill"></image>
						<view class="pinglunName">{{item.name}}</view>
						<u-rate :count="count" size="16" gutter="0" v-model="item.score"></u-rate>
					</view>
					<view class="pinglunTopRight">
						2012-10-10
					</view>
				</view>
				<view class="pinglunBottom">
					<view class="pinglunBottomTitle">{{item.content}}</view>
					<scroll-view 
						scroll-x="true"
						>
						<view class="pinglunBottomScroolView">
							<image 
							v-for="(item,index) in item.pingImage"
							:key="item.id"
							class="pinglunBottomImage" 
							:src="item.image" 
							mode="aspectFill"></image>
						</view>
					</scroll-view>
				</view>
			</view>
		</view>
		
		
		<!-- 问答 -->
		<view class="pingBox">
			<view class="pingTop">
				<view class="pinglun">问答</view>
				<view class="pingTopRight">
					<view class="haoping">查看全部问题</view>
					<u-icon name="arrow-right" size="30"></u-icon>
				</view>
			</view>
			<view class="problem">
				<view class="problemLeft">
					<view class="problemMsg"><text class="problemType">问</text>存储卡用哪一款</view>
					<view class="problemFont">共1个问题</view>
				</view>
				<view class="problemRight">
					<view class="problemMsg"><text class="problemType">问</text>这是微单还是数码相机?</view>
					<view class="problemFont">共1个问题</view>
				</view>
			</view>
		</view>
		
		<view class="kongDiv">
		</view>
		
		<!-- 店铺信息 -->
		<view class="sxMsg">
			<view class="sxMsgTop">
				<image class="sxlogo" src="../../static/image/sxlogo.webp" mode="aspectFill"></image>
				<view class="sxname">松下影像京东自营官方旗舰店</view>
				<view class="sxway">京东自营</view>
			</view>
			<view class="sxMsgContent">
				<view>
					<view style="text-align: center;">34万</view>
					<view class="sxfont">粉丝人数</view>
				</view>
				<view>
					<view style="text-align: center;">34</view>
					<view class="sxfont">全部商品</view>
				</view>
			</view>
			<view class="sxMsgBottom">
				<view class="sxBtnLeft">
					<u-icon class="sxBtnIcon" name="star" color="#999"size="36"></u-icon>
					<view class="sxBtnTitle">关注店铺</view>
				</view>
				<view class="sxBtnRight">
					<u-icon class="sxBtnIcon" name="home"  color="#999" size="36"></u-icon>
					<view class="sxBtnTitle">进入店铺</view>
				</view>
			</view>
		</view>
		
		
		<view class="kongDiv">
		</view>
		
		<!-- 高价回收 -->
		<view class="recycleBox">
			<view class="recycleItem">
				<image class="recycleImage"
				src="../../static/image/phoneLogo.png"
				mode="aspectFill"></image>
				<view class="recycleRight">
					<view class="recycleTitle">高价回收</view>
					<view class="recycleContent">
						旧品回收，免费估价，极速到账
					</view>
				</view>
			</view>
		</view>
		
		<view class="kongDiv">
		</view>
		
		<!-- 热门配件推荐 -->
		<view class="hotTuiJian">
			<view class="hotItem">
				<view class="hotItemTop">
					<view>热门配件推荐</view>
					<view class="hotItemTopRight">
						<view class="recycleContent">查看全部数码配件</view>
						<u-icon name="arrow-right" size="26"></u-icon>
					</view>
				</view>
				<view class="hotItemBottom">
					<image class="hotImage" src="/static/image/hotShop1.png"></image>
					<image class="hotImage" src="/static/image/hotShop2.png"></image>
					<image class="hotImage" src="/static/image/hotShop3.png"></image>
				</view>
			</view>
		</view>
		
		<view class="kongDiv">
		</view>
		
		
		<!-- 猜你喜欢 -->
		<view class="guessLike">
			<view class="guessLikeTop">
				<view>配件推荐</view>
				<view class="guessLikeType">猜你喜欢</view>
			</view>
			
			<swiper class="swiper" @change="change">
				<swiper-item>
					<u-grid col="3" :border="false">
						<u-grid-item
						class="grid-item"
						v-for="(item,index) in likelist"
						v-if="item.id<7"
						:key="item.id">
							<view>
								<image class="likeImage" :src="item.image"
								mode="aspectFill"></image>
								<view class="likeTitle">{{item.title}}</view>
								<view class="likePrice">{{item.price}}</view>
							</view>
						</u-grid-item>
					</u-grid>
				</swiper-item>
				<swiper-item>
					<u-grid col="3" :border="false">
						<u-grid-item
						class="grid-item"
						v-for="(item,index) in likelist"
						v-if="item.id>6"
						:key="item.id">
							<view>
								<image class="likeImage" :src="item.image"
								mode="aspectFill"></image>
								<view class="likeTitle">{{item.title}}</view>
								<view class="likePrice">{{item.price}}</view>
							</view>
						</u-grid-item>
					</u-grid>
				</swiper-item>
			</swiper>
			<view class="indicator-dots">
				<view class="indicator-dots-item" :class="[current == 0 ? 'indicator-dots-active' : '']">
				</view>
				<view class="indicator-dots-item" :class="[current == 1 ? 'indicator-dots-active' : '']">
				</view>
			</view>
		</view>
		
		
		<view class="kongDiv">
		</view>
		
		<!-- 商品介绍 -->
		<view class="letter">
			<view class="shopLetter">
				<view class="shopLetterTitle">商品介绍</view>
				<view>规格参数</view>
				<view>善后保障</view>
			</view>
		</view>
		<!-- 实例图 -->
		<view class="shili">
			<image class="shiliImage" src="../../static/image/shili1.png" mode="aspectFill"></image>
			<image class="shiliImage" src="../../static/image/shili2.png" mode="aspectFill"></image>
			<image class="shiliImage" src="../../static/image/shili3.png" mode="aspectFill"></image>
			<image class="shiliImage" src="../../static/image/shili4.png" mode="aspectFill"></image>
			<image class="shiliImage" src="../../static/image/shili5.png" mode="aspectFill"></image>
			<image class="shiliImage" src="../../static/image/shili6.png" mode="aspectFill"></image>
			<image class="shiliImage" src="../../static/image/shili7.png" mode="aspectFill"></image>
			<image class="shiliImage" src="../../static/image/shili8.png" mode="aspectFill"></image>
		</view>
		
		

		<!-- 提交订单栏 -->
		<view class="navigation">
			<view class="left">
				<view class="item car">
					<u-icon name="home" :size="40" :color="$u.color['contentColor']"></u-icon>
					<view class="text u-line-1">店铺</view>
				</view>
				<view class="item car">
					<u-icon name="server-man" :size="40" :color="$u.color['contentColor']"></u-icon>
					<view class="text u-line-1">客服</view>
				</view>
				
				<view class="item car">
					<u-icon name="shopping-cart" :size="40" :color="$u.color['contentColor']"></u-icon>
					<view class="text u-line-1">购物车</view>
				</view>
			</view>
			<view class="right">
				<view class="cart btn u-line-1">加入购物车</view>
				<view class="buy btn u-line-1">立即购买</view>
			</view>
		</view>
		
	</view>
</template>

<script>
	export default {
		data(){
			return{
				current: 0,
				count: 5,
				zongZhi:'/static/image/songZhilogo.png',
				showNum:1,
				swiperlist:[
					{
						id:1,
						image:'/static/image/shopMsg1.webp'
					},{
						id:2,
						image:'/static/image/shopMsg2.webp'
					},{
						id:3,
						image:'/static/image/shopMsg3.webp'
					},{
						id:4,
						image:'/static/image/shopMsg4.webp'
					},{
						id:5,
						image:'/static/image/shopMsg5.webp'
					},{
						id:6,
						image:'/static/image/shopMsg6.webp'
					},{
						id:7,
						image:'/static/image/shopMsg7.webp'
					},
				],
				pingModulelist:[
					{
						id:1,
						content:'颜值够高(4)'
					},{
						id:2,
						content:'携带方便(4)'
					},{
						id:3,
						content:'十分漂亮(2)'
					},{
						id:4,
						content:'便携小巧(1)'
					},{
						id:5,
						content:'小巧便携(1)'
					},{
						id:6,
						content:'颜色漂亮(1)'
					},
				],
				pinglist:[
					{
						id:1,
						name:'真***喔',
						score:5,
						image:'/static/image/home1.jpg',
						time:'2018-12-25',
						content:'包装完好，外形时尚好看，颜色很梦幻。松下作为大牌质量方面也比较放心。拍出来的相片美肤效果比较自然，不失真，还原度到位，像自带滤镜一样！电池容量再大点就好了，轻巧方便，手感舒适，WIFI 功能非常方便，价格不贵物美价廉，推荐入手！',
						pingImage:[
							{
								id:1,
								image:'/static/image/home1ping1.webp'
							},{
								id:2,
								image:'/static/image/home1ping2.webp'
							},{
								id:3,
								image:'/static/image/home1ping3.webp'
							},{
								id:4,
								image:'/static/image/home1ping4.webp'
							},{
								id:5,
								image:'/static/image/home1ping5.webp'
							},
						]
					},{
						id:2,
						name:'MeiXi',
						score:5,
						image:'/static/image/home2.jpg',
						time:'2019-01-03',
						content:'产品包装：包装非常好，隔日达，没有任何损坏的地方，相机拿出来那一刻手感特别好，做工无可挑剔，玫瑰金粉特别好看。 外形外观：形外观非常小巧，手掌大小，也不重，非常便携，功能特别多，4k录像特别好，得好好研究一下了，小白一个啊。 成像效果：聚焦非常好，画质清楚，拍出来的东西比手机拍出来的好。 反应速度：应速度非常快，无卡顿，不错，值得入手。',
						pingImage:[
							{
								id:1,
								image:'/static/image/home2ping1.webp'
							},{
								id:2,
								image:'/static/image/home2ping2.webp'
							},{
								id:3,
								image:'/static/image/home2ping3.webp'
							},{
								id:4,
								image:'/static/image/home2ping4.webp'
							},{
								id:5,
								image:'/static/image/home2ping5.webp'
							},
						]
					}
				],
				likelist:[
					{
						id:1,
						image:'/static/image/like1.webp',
						title:'富士XA3 16-50单电自拍微单相机富士X-A3 XA2 XM1士X-A2单机9新 官标配',
						price:'￥3579.00'
					},
					{
						id:2,
						image:'/static/image/like2.webp',
						title:'富士XA3 16-50单电自拍微单相机富士X-A3 XA2 XM1士X-A2单机9新 官标配',
						price:'￥3579.00'
					},
					{
						id:3,
						image:'/static/image/like3.webp',
						title:'富士XA3 16-50单电自拍微单相机富士X-A3 XA2 XM1士X-A2单机9新 官标配',
						price:'￥3579.00'
					},
					{
						id:4,
						image:'/static/image/like4.webp',
						title:'富士XA3 16-50单电自拍微单相机富士X-A3 XA2 XM1士X-A2单机9新 官标配',
						price:'￥3579.00'
					},
					{
						id:5,
						image:'/static/image/like5.webp',
						title:'富士XA3 16-50单电自拍微单相机富士X-A3 XA2 XM1士X-A2单机9新 官标配',
						price:'￥3579.00'
					},
					{
						id:6,
						image:'/static/image/like6.webp',
						title:'富士XA3 16-50单电自拍微单相机富士X-A3 XA2 XM1士X-A2单机9新 官标配',
						price:'￥3579.00'
					},{
						id:7,
						image:'/static/image/like7.webp',
						title:'富士XA3 16-50单电自拍微单相机富士X-A3 XA2 XM1士X-A2单机9新 官标配',
						price:'￥3579.00'
					},{
						id:8,
						image:'/static/image/like8.webp',
						title:'富士XA3 16-50单电自拍微单相机富士X-A3 XA2 XM1士X-A2单机9新 官标配',
						price:'￥3579.00'
					},{
						id:9,
						image:'/static/image/like9.webp',
						title:'富士XA3 16-50单电自拍微单相机富士X-A3 XA2 XM1士X-A2单机9新 官标配',
						price:'￥3579.00'
					},{
						id:10,
						image:'/static/image/like10.webp',
						title:'富士XA3 16-50单电自拍微单相机富士X-A3 XA2 XM1士X-A2单机9新 官标配',
						price:'￥3579.00'
					},{
						id:11,
						image:'/static/image/like11.webp',
						title:'富士XA3 16-50单电自拍微单相机富士X-A3 XA2 XM1士X-A2单机9新 官标配',
						price:'￥3579.00'
					},{
						id:12,
						image:'/static/image/like12.webp',
						title:'富士XA3 16-50单电自拍微单相机富士X-A3 XA2 XM1士X-A2单机9新 官标配',
						price:'￥3579.00'
					},
				]
				
			}
		},
		methods:{
			backPage(){
				uni.navigateBack({
					delta:1
				})
			},
			changSwiper(e){
				console.log(e)
				this.showNum = e.detail.current+1
			},
			change(e) {
				this.current = e.detail.current;
			}
		}
	}
</script>

<style lang="scss" scoped>
	.shopPageBox{
		padding-bottom: 104rpx;
	}
	.kongDiv{
		width: 750rpx;
		height:20rpx;
		background-color: #f2f2f2;
	}
	.navLogo{
		// display: flex;
		// justify-content: space-between;
		// margin: 10rpx;
		
	}
	.navLogoLeft{
		position: fixed;
		top: 12rpx;
		left: 12rpx;
		color: #fff;
		background-color: #666666;
		padding: 5rpx;
		border-radius: 30rpx;
		z-index: 999;
	}
	.navLogoRight{
		position: fixed;
		top: 12rpx;
		right: 12rpx;
		color: #fff;
		background-color: #666666;
		padding: 5rpx;
		border-radius: 30rpx;
		z-index: 999;
	}
	.swiper{
		width: 750rpx;
		height: 750rpx;
	}
	.swiper-item{
		width: 100%;
		height: 100%;
	}
	.swiperImage{
		width: 100%;
		height: 100%;
	}
	.logo618{
		width: 750rpx;
		height: 100rpx;
	}
	.showNum{
		width: 120rpx;
		background-color: #cccccc;
		color:#fff;
		text-align: center;
		border-radius: 30rpx;
		position: absolute;
		right: -16rpx;
		top: 680rpx;
		z-index: 999;
	}
	
	// 商品价格 状态
	.shopPrice{
		margin: 0 25rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.shopPriceLeft{
		display: flex;
		color: #fc3f2d;
		align-items: flex-end;
		
	}
	.rmb{
		font-size: 38rpx;
	}
	.rmbPrice{
		font-size: 60rpx;
		transform: translate(0px,3px);
	}
	.rmbFloat{
		font-size: 38rpx;
	}
	.shopPriceRight{
		display: flex;
	}
	.remind1{
		transform: translate(-17px,0px);
		font-size: 16rpx;
	}
	.remind2{
		transform: translate(-5px,0px);
		font-size: 16rpx;
	}
	
	// 商品标题
	.shopBigTitleMsg{
		margin: 30rpx 25rpx;
	}
	.shopBigTitle{
		margin-bottom: 30rpx;
	}
	.shopWay{
		font-size: 18rpx;
		color: #fff;
		background-color: #fc3f2d;
		padding: 2rpx 6rpx;
		border-radius: 10rpx;
		margin-right: 10rpx;
	}
	.shopBigTitle view:nth-child(1){
		font-size: 36rpx;
		font-weight: bold;
	}
	.shopBigTitleBottom{
		font-size:26rpx;
	}
	.shopBigTitleBottom text{
		color: #fc3f2d;
	}
	
	
	// 优惠
	.youHui{
		margin: 0 25rpx;
		padding: 20rpx 0;
	}
	.youHuiMsg{
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		
	}
	.youHuiMsg text:nth-child(1){
		font-weight: bold;
		// padding-right: 20rpx;
		margin-right: 30rpx;
	}
	.youHuiMsg text:nth-child(2){
		color: #fc3f2d;
		border: 1rpx solid #fc3f2d;
		margin-right: 18rpx;
		font-size: 24rpx;
	}
	
	
	// 已选
	.yiXuan{
		display: flex;
		margin: 0 25rpx;
		padding: 30rpx 0;
	}
	.yiXuanLeft{
		width: 108rpx;
		font-weight: bold;
	}
	.yiXuanRight{
		
	}
	.yiXuanRight view:nth-child(1){
		margin-bottom: 10rpx;
	}
	.yiXuanRight view:nth-child(2){
		color: #999;
		font-size: 18rpx;
	}
	
	// 送至
	.songZhi{
		display: flex;
		margin: 0 25rpx;
		padding: 30rpx 0;
	}
	.songZhiLeft{
		width: 94rpx;
		font-weight: bold;
	}
	.songZhiRight{
		
	}
	.songZhiRight view:nth-child(2){
		margin-top: 10rpx;
		font-size: 18rpx;
		color: #999;
	}
	.songZhiImage{
		width: 140rpx;
		height: 26rpx;
	}
	.songZhiXianhuo{
		margin: 0 10rpx;
		color: #fc3f2d;
		font-size: 18rpx;
	}
	
	// 重量
	.shopWeight{
		display: flex;
		margin: 0 25rpx;
		padding: 30rpx 0;
	}
	.shopWeight view:nth-child(1){
		width: 94rpx;
		font-weight: bold;
	}
	
	
	// 更多内容
	.someMsg{
		margin: 0 25rpx;
		padding: 30rpx 0;
	}
	.someMsg .someIcon{
		margin-right: 10rpx;
	}
	.someMsgTop{
		display: flex;
	}
	.someMsgConetent{
		display: flex;
	}
	.someMsgConetent view:nth-child(1){
		display: flex;
	}
	.someMsgConetent view:nth-child(2){
		display: flex;
	}
	.someMsgBottom{
		display: flex;
	}
	.someMsgBottom view:nth-child(1){
		display: flex;
	}
	.someMsgBottom view:nth-child(2){
		display: flex;
	}
	.someMsgBottom view:nth-child(3){
		display: flex;
	}
	.someMsgBottom view:nth-child(4){
		display: flex;
	}
	.someFont{
		font-size: 18rpx;
		color: #999;
	}
	.someMsgItem{
		margin-right: 30rpx;
	}
	
	
	
	// 评论内容
	.pingBox{
		margin: 0 25rpx;
		padding: 30rpx 0;
	}
	.pingTop{
		display: flex;
		justify-content: space-between;
	}
	.pinglun{
		border-left: 3px solid #fc3f2d;
		padding-left: 10rpx;
		font-weight: bold;
		font-size:30rpx;
	}
	.pingNum{
		margin-left: 15rpx;
		font-size: 24rpx;
	}
	.pingTopRight{
		display: flex;
		align-items: center;
	}
	.haoping{
		color: #999;
		font-size: 24rpx;
	}
	
	.pingModule{
		padding: 30rpx 0;
		display: flex;
		flex-wrap: wrap;
	}
	.pingModuleItem{
		margin: 10rpx 20rpx 10rpx 0;
		width: 178rpx;
		text-align: center;
		background-color: #fcedeb;
		border-radius: 30rpx;
		padding: 10rpx 0;
		font-size: 24rpx;
	}
	
	// 评论详情
	.pinglunMsg{
		margin: 20rpx 0;
		border-bottom: 1px solid #e7e7e7;
		padding-bottom: 50rpx;
	}
	.pinglunTop{
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.pinglunTopLeft{
		display: flex;
		align-items: center;
	}
	.pinglunImage{
		width: 40rpx;
		height: 40rpx;
		border-radius: 20rpx;
		margin-right: 20rpx;
	}
	.pinglunName{
		margin-right: 20rpx;
		font-size: 24rpx;
	}
	.pinglunTopRight{
		font-size: 24rpx;
		color: #999;
	}
	
	.pinglunBottomTitle{
		margin: 30rpx 0;
		overflow: hidden;
		display: -webkit-box;
		-webkit-box-orient:vertical;
		-webkit-line-clamp:3;
	}
	.pinglunBottomScroolView{
		display: flex;
		width: 120%;
	}
	.pinglunBottomImage{
		margin: 5rpx 5rpx;
		width: 160rpx;
		height: 160rpx;
		border-radius: 20rpx;
	}
	
	// 问答
	.problem{
		margin-left: 20rpx;
	}
	.problemType{
		background-color: #ff9600;
		color: #fff;
		border-radius: 5rpx;
		margin: 0 10rpx 0 0;
	}
	.problemLeft{
		display: flex;
		justify-content: space-between;
		margin: 20rpx 0;
		justify-content: space-between;
	}
	.problemRight{
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.problemFont{
		font-size: 24rpx;
		color: #999;
	}
	
	
	
	// 松下店铺介绍
	.sxMsg{
		margin: 30rpx 25rpx;
	}
	.sxMsgTop{
		display: flex;
		align-items: center;
	}
	.sxlogo{
		width: 80rpx;
		height: 80rpx;
		border-radius: 15rpx;
	}
	.sxname{
		margin-left: 30rpx;
	}
	.sxway{
		margin-left: 20rpx;
		font-size: 24rpx;
		background-color: #fc3f2d;
		color: #fff;
		border-radius: 5rpx;
	}
	.sxMsgContent{
		margin:30rpx 0 ;
		display: flex;
		justify-content: space-around;
	}
	.sxfont{
		color: #999;
		font-size: 24rpx;
	}
	.sxMsgBottom{
		display: flex;
		justify-content: space-around;
		align-items: center;
	}
	.sxBtnLeft{
		display: flex;
		border: 1px solid #999;
		padding: 10rpx 30rpx;
		border-radius: 30rpx;
	}
	.sxBtnRight{
		display: flex;
		border: 1px solid #999;
		padding: 10rpx 30rpx;
		border-radius: 30rpx;
	}
	.sxBtnIcon{
		transform: translate(-6rpx,-2rpx);
	}
	
	
	// 高价回收
	.recycleBox{
		margin: 30rpx 25rpx;
	}
	.recycleItem{
		display: flex;
	}
	.recycleImage{
		width: 40rpx;
		height: 44rpx;
	}
	.recycleRight{
		margin-left: 20rpx;
	}
	.recycleContent{
		font-size: 24rpx;
		color: #999;
	}
	
	
	
	// 热门配件推荐
	.hotTuiJian{
		margin: 30rpx 25rpx;
	}
	.hotItem{
		
	}
	.hotItemTop{
		display: flex;
		justify-content: space-between;
	}
	.hotItemTopRight{
		display: flex;
	}
	.hotItemBottom{
		display: flex;
		flex-wrap: wrap;
		margin: 10rpx 20rpx;
	}
	
	.hotImage{
		width: 220rpx;
		height: 126rpx;
	}
	
	

	// 猜你喜欢 
	.guessLike{
		margin: 30rpx 0rpx;
	}
	.guessLikeTop{
		display: flex;
		justify-content: space-around;
	}
	.guessLikeType{
		font-weight: bold;
		border-bottom: 2px solid #fc3f2d;
		padding-bottom: 5rpx;
	}
	
	.grid-item{
		width: 200rpx;
	}
	.likeImage{
		width: 200rpx;
		height: 220rpx;
	}
	.likeTitle{
		width: 200rpx;
		font-size: 24rpx;
		overflow: hidden;
		display: -webkit-box;
		-webkit-box-orient:vertical;
		-webkit-line-clamp:2;
	}
	.likePrice{
		color: #fc3f2d;
		font-weight: bold;
	}
	
	
	.grid-text {
		font-size: 28rpx;
		margin-top: 4rpx;
		color: $u-type-info;
	}
	.swiper {
			height: 750rpx;
		}
	.indicator-dots {
		margin-top: 20rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.indicator-dots-item {
		background-color: #999;
		height: 6px;
		width: 6px;
		border-radius: 10px;
		margin: 0 3px;
	}
	.indicator-dots-active {
		background-color: #fc3f2d;
	}
	
	
	// 商品介绍
	.letter{
		margin: 30rpx 25rpx;
	}
	.shopLetter{
		display: flex;
		justify-content: space-around;
	}
	.shopLetterTitle{
		font-weight: bold;
		border-bottom: 2px solid #fc3f2d;
		padding-bottom: 5rpx;
	}
	
	// 实例图
	.shiliImage{
		width: 750rpx;
		// height: 300rpx;
	}
	
	
	// 提交订单栏
	.navigation {
		width: 750rpx;
		position: fixed;
		bottom: 0rpx;
		display: flex;
		margin-top: 100rpx;
		border: solid 2rpx #f2f2f2;
		background-color: #ffffff;
		padding: 16rpx 0;
		.left {
			display: flex;
			font-size: 20rpx;
			.item {
				margin: 0 30rpx;
				&.car {
					text-align: center;
				}
			}
		}
		.right {
			display: flex;
			font-size: 28rpx;
			font-weight: bold;
			align-items: center;
			.btn {
				line-height: 66rpx;
				padding: 0 26rpx;
				border-radius: 36rpx;
				color: #ffffff;
			}
			.cart {
				background-color: #fc3f2d;
				margin-right: 30rpx;
			}
			.buy {
				background-color: #ffc60d;
			}
		}
	}
</style>
