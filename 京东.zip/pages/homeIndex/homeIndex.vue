<template>
	<view>
		<u-navbar :border-bottom="false" :is-back="false" :background="background" height="50">
			<u-icon class="navLogo" name="list" size="46" color="#fff"></u-icon>
			<view class="logoJD">JD</view>
			<u-icon class="logoIcon" name="search" size="46" color="#aaa"></u-icon>
			<u-input class="goInput" placeholder="商务休闲鞋"></u-input>
			<view class="goLogin">登录</view>
		</u-navbar>
		
		<view class="background">
			
		</view>
		
		<!-- 返回顶部 -->
		<u-back-top :scroll-top="scrollTop" top="100"></u-back-top>
		<!-- 轮播图 -->
		<view class="pageBox">
			<view class="redBackground">
				<swiper 
					class="swiper"
					autoplay="" 
					circular=""
					indicator-active-color="#c82519"
					indicator-color="#fff"
					indicator-dots=""
					interval="2000">
					<swiper-item
					class="swiper-item"
						v-for="(item,index) in lunbolist"
						:key="item.id">
						<image :src="item.image"></image>
					</swiper-item>
				</swiper>
			</view>
		</view>
		
		<!-- grid布局 -->
		<swiper class="gridSwiper" @change="change">
			<swiper-item>
				<u-grid col="5" :border="false">
					<u-grid-item v-for="(item,index) in gridlist"
						:key="item.id" v-if="item.id<11"
						@click="gotoGrid(item.id)">
						<u-icon :name="item.image" size="55"></u-icon>
						<text class="grid-text">{{item.title}}</text>
					</u-grid-item>
				</u-grid>
			</swiper-item>
			<swiper-item>
				<u-grid col="5" :border="false">
					<u-grid-item v-for="(item,index) in gridlist"
						:key="item.id" v-if="item.id>10">
						<u-icon :name="item.image" size="55"></u-icon>
						<text class="grid-text">{{item.title}}</text>
					</u-grid-item>
				</u-grid>
			</swiper-item>
		</swiper>
		<view class="indicator-dots">
			<view class="indicator-dots-item" :class="[current == 0 ? 'indicator-dots-active' : '']">
			</view>
			<view class="indicator-dots-item" :class="[current == 1 ? 'indicator-dots-active' : '']">
			</view>
		</view>
		
		<!-- 秒杀环节 -->
		<view class="seckill">
			<view class="seckillTop">
				<view class="seckillTopLeft">
					<view>京东秒杀</view>
					<view class="seckillTime">6 点场</view>
					<view class="seckillFall">00:00:00</view>
				</view>
				<view class="seckillTopRight">
					<view class="seckillTopRightTitle">爆款轮番秒</view>
					<u-icon class="seckillTopRightIcon" name="arrow-right" size="22"></u-icon>
				</view>
			</view>
			<view class="seckillBottom">
				<view class="seckillBottomItem"
					v-for="(item,index) in mslist"
					:key="item.id">
					<image  class="seckillBottomImage"
					:src="item.image" mode=""></image>
					<view class="seckillPrice">{{item.price}}</view>
				</view>
			</view>
		</view>
		
		<!-- 商品列表 -->
		<view class="shopBox">
			<view class="shopItem"
				@click="gotoShop"
				v-for="(item,index) in shoplist"
				:key="item.id">
				<image class="shopImage" :src="item.image"></image>
				<view class="shopTitle">{{item.title}}</view>
				<view class="shopPrice">￥{{item.price}}</view>
				<view class="shopBottom">
					<view 
					:class="item.way == '自营' ? 'shopBottomLeft':'shopBottomLeftTow'"
					>{{item.way}}</view>
					<view class="shopBottomRight">看相似</view>
				</view>
			</view>
		</view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				scrollTop:0,
				current:0,
				background:{
					backgroundColor:'#fc3f2d'
				},
				actionStyle:{
					color:'#fff'
				},
				lunbolist:[
					{
						id:1,
						image:'/static/image/lunbo1.jpg'
					},{
						id:2,
						image:'/static/image/lunbo2.jpg'
					},{
						id:3,
						image:'/static/image/lunbo3.jpg'
					},{
						id:4,
						image:'/static/image/lunbo4.jpg'
					},
					
				],
				gridlist:[
					{
						id:1,
						image:'/static/image/grid1.png',
						title:'京东超市'
					},{
						id:2,
						image:'/static/image/grid2.png',
						title:'数码电器'
					},{
						id:3,
						image:'/static/image/grid3.png',
						title:'京东服饰'
					},{
						id:4,
						image:'/static/image/grid4.png',
						title:'京东生鲜'
					},{
						id:5,
						image:'/static/image/grid5.png',
						title:'京东到家'
					},{
						id:6,
						image:'/static/image/grid6.png',
						title:'充值缴费'
					},{
						id:7,
						image:'/static/image/grid7.png',
						title:'物流查询'
					},{
						id:8,
						image:'/static/image/grid8.png',
						title:'领券'
					},{
						id:9,
						image:'/static/image/grid9.png',
						title:'领金贴'
					},{
						id:10,
						image:'/static/image/grid10.png',
						title:'PLUS会员'
					},{
						id:11,
						image:'/static/image/grid11.png',
						title:'京东国际'
					},{
						id:12,
						image:'/static/image/grid12.png',
						title:'京东拍卖'
					},{
						id:13,
						image:'/static/image/grid13.png',
						title:'看病购药'
					},{
						id:14,
						image:'/static/image/grid14.png',
						title:'玩3C'
					},{
						id:15,
						image:'/static/image/grid15.png',
						title:'沃尔玛'
					},{
						id:16,
						image:'/static/image/grid16.png',
						title:'美妆馆'
					},{
						id:17,
						image:'/static/image/grid17.png',
						title:'京东旅行'
					},{
						id:18,
						image:'/static/image/grid18.png',
						title:'拍拍二手'
					},{
						id:19,
						image:'/static/image/grid19.png',
						title:'潮燃青年'
					},{
						id:20,
						image:'/static/image/grid20.png',
						title:'全部'
					},
				],
				mslist:[
					{
						id:1,
						image:'/static/image/ms1.png',
						price:'￥338'
					},{
						id:2,
						image:'/static/image/ms2.png',
						price:'￥70'
					},{
						id:3,
						image:'/static/image/ms3.png',
						price:'￥685'
					},{
						id:4,
						image:'/static/image/ms4.png',
						price:'￥6569'
					},{
						id:5,
						image:'/static/image/ms5.png',
						price:'￥2169'
					},{
						id:6,
						image:'/static/image/ms6.png',
						price:'￥79'
					},
				],
				shoplist:[
					{
						id:1,
						image:'/static/image/shop1.webp',
						title:'[六头更专业] JOVS脱毛仪器冰点激光女士家男土面部唇部唇毛胡子无痛去毛仪腋下脸部光子净毛剃毛器[礼盒款] 祖母绿A-二代旗舰店版(配6个头)',
						price:'2389.00',
						way:'京东物流'
					},{
						id:2,
						image:'/static/image/shop2.webp',
						title:'松下(Panasonic) GF10K微单相机数码相机vlog相机微单套机(12-32mm) 4K视频美颜自拍粉色',
						price:'2998.00',
						way:'自营'
					},{
						id:3,
						image:'/static/image/shop3.webp',
						title:'华帝百得22立方大吸力侧吸式油烟机自动清洗厨房脱排抽油烟机单烟机家用吸油烟机E319C天然气(12T)',
						price:'1599.00',
						way:'京东物流'
					},{
						id:4,
						image:'/static/image/shop4.webp',
						title:'索尼(SONY) Alpha 6400 APS-C画幅微单数码相机标准套装艷(SELP1650镜头ILCE-6400L/A6400L _/a6400)',
						price:'8599.00',
						way:'自营'
					},{
						id:5,
						image:'/static/image/shop5.webp',
						title:'自梦大王GOON花信风短裤型尿不湿XL 40片(12-17kg)婴儿加大号超薄透气',
						price:'149.00',
						way:'自营'
					},{
						id:6,
						image:'/static/image/shop6.webp',
						title:'曾华帝(VATTI) JZT- i10059B (天然气)燃气灶双灶台打火灶具4.5kW猛火家用台嵌两用炉头可拆洗以旧换新',
						price:'999.00',
						way:'自营'
					}
				]
			}
		},
		onPageScroll(e) {
			this.scrollTop = e.scrollTop;
		},
		methods: {
			change(e){
				this.current = e.detail.current
			},
			gotoGrid(id){
				if(id == 6){
					uni.navigateTo({
						url:'mobilePhone'
					})
				}
			},
			gotoShop(){
				uni.navigateTo({
					url:'shopPage'
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.navLogo{
		padding-left: 30rpx;
	}
	// .search{
	// 	padding: 0 30rpx;
	// }
	.logoJD{
		position: fixed;
		left: 130rpx;
		top: 30rpx;
		z-index: 999;
		font-size:42rpx;
		color: #fc3f2d;
		border-right: 2rpx solid #aaa;
		padding-right: 16rpx;
		height: 40rpx;
		line-height: 40rpx;
	}
	.logoIcon{
		position: fixed;
		left: 210rpx;
		top: 26rpx;
		z-index: 999;
	}
	.goInput{
		// height: 60rpx;
		// line-height: 60rpx;
		background-color: #fff;
		border-radius: 40rpx;
		text-indent: 6.5em;
		margin: 0 30rpx;
	}
	.goLogin{
		color: #fff;
		margin-right: 30rpx;
	}
	// .redBackground{
	// 	height: 200rpx;
	// 	background-color:#c82519;
	// 	border-bottom-right-radius: 200rpx;
	// 	border-bottom-left-radius: 200rpx;
	// }
	.pageBox{
		margin: 0 25rpx;
	}
	.background{
		position: absolute;
		left: -25%;
		width: 150%;
		height: 220rpx;
		background-color: #fc3f2d;
		border-bottom-left-radius: 100%;
		border-bottom-right-radius: 100%;
	}
	.swiper{
		margin-top: 30rpx;
		width: 700rpx;
		height: 280rpx;
		// border-radius: 20rpx;
	}
	.swiper-item{
		width: 100%;
		height: 100%;
		// border-radius: 20rpx;
	}
	.swiper-item image{
		width: 100%;
		height: 100%;
		border-radius: 20rpx;
	}
	
	// grid 样式
	.gridSwiper{
	}
	.indicator-dots {;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	
	.indicator-dots-item {
		background-color: #999;
		height: 6px;
		width: 6px;
		border-radius: 10px;
		margin: 0 3px;
	}
	
	.indicator-dots-active {
		background-color: #fc3f2d;
	}
	
	// 京东秒杀
	.seckill{
		margin: 20rpx 25rpx;
	}
	.seckillTop{
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.seckillTopLeft{
		display: flex;
		align-items: center;
	}
	.seckillTime{
		padding-left: 20rpx;
		color: #fc3f2d;
		font-size: 24rpx;
	}
	.seckillFall{
		margin-left: 20rpx;
		padding:0rpx 5rpx;
		border-radius: 10rpx;
		color: #fff;
		background-color: #fc3f2d;
		font-size: 24rpx;
	}
	.seckillTopRight{
		display: flex;
		align-items: center;
	}
	.seckillTopRightTitle{
		font-size: 24rpx;
		color: #fc3f2d;
	}
	.seckillTopRightIcon{
		margin-left: 5rpx;
		background-color: #fc3f2d;
		border-radius: 30rpx;
		width: 22rpx;
		height: 22rpx;
		color: #fff;
		transform: translate(10rpx,3rpx);
	}
	.seckillBottom{
		display: flex;
		flex-wrap: nowrap;
	}
	.seckillBottomItem{
		margin: 20rpx 5rpx;
	}
	.seckillBottomImage{
		width: 110rpx;
		height: 110rpx;
	}
	.seckillPrice{
		text-align: center;
		color: #fc3f2d;
	}
	.shopBox{
		margin: 20rpx 25rpx;
		display: flex;
		flex-wrap: wrap;
	}
	.shopItem{
		width: 320rpx;
		height: 560rpx;
		margin: 20rpx 15rpx;
	}
	.shopImage{
		width: 100%;
		height:340rpx;
		border-radius: 20rpx;
	}
	.shopTitle{
		overflow: hidden;
		display: -webkit-box;
		-webkit-box-orient:vertical;
		-webkit-line-clamp:2;
	}
	.shopPrice{
		color: #fc3f2d;
		font-weight: bold;
	}
	.shopBottom{
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.shopBottomLeft{
		font-size: 18rpx;
		color: #fff;
		background-color: #fc3f2d;
		padding: 2rpx 6rpx;
		border-radius: 10rpx;
	}
	.shopBottomLeftTow{
		font-size: 18rpx;
		color: #fc3f2d;
		background-color: #fff0f0;
		padding: 2rpx 6rpx;
		border-radius: 10rpx;
	}
	
	.shopBottomRight{
		background-color: #eee;
		padding: 6rpx 10rpx;
		border-radius: 30rpx;
		font-size: 18rpx;
	}
</style>
