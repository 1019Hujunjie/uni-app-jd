<template>
	<view>
		<!-- 自定义导航栏 -->
		<u-navbar title="话费充值">
			<u-icon 
				class="navIcon" 
				name="more-dot-fill" 
				size="46"
				color="#999"
			></u-icon>
		</u-navbar>
		
		<view class="mobileLogo">
			<view class="mobileLogoLeft">
				<image class="mobileImage" src="../../static/image/JDlogo.jpg" mode="aspectFill"></image>
				<view class="phonePrice">手机充值</view>
			</view>
			<view class="mobileLogoRight">
				<view class="guanzhuNum">111万人关注</view>
				<view class="guanzhu">
					<u-icon class="guanzhuIcon" name="heart"></u-icon>
					<view>关注</view>
				</view>
			</view>
		</view>
		
		<!-- 充值标题 -->
		<view class="mobileTitle">
			<view
				v-for="(item,index) in mobileType"
				:key="item.id"
				:class="item.id == typeId ? 'typeBottom':'mobileTitleFont'"
				@click="clickMobileType(item.id)">
				{{item.title}}
			</view>
		</view>
		
		<!-- 充值主页面 -->
		<view class="mobileBox">
			<u-form>
				<u-form-item>
					<u-input 
						:placeholder-style="placeholderStyle"
						height="100"
						class="phoneInput"
						placeholder="请输入11位手机号码"
						v-model.trim="phone"
					></u-input>
				</u-form-item>
			</u-form>
			<view class="priceBox">
				<view class="priceItem"
					v-for="(item,index) in pricelist"
					:key="item.id">
					<view class="priceContent">
						<view class="priceItemMsg">{{item.price}}</view>
						<view class="priceYuan">元</view>
					</view>
				</view>
			</view>
			
			<!-- 充值按钮 -->
			<view class="btn">
				<button class="button">￥0.00 立即充值</button>
			</view>
			<view class="footer">订单完成后可在订单详情页查看商家信息</view>
		</view>
	</view>
</template>

<script>
	export default {
		data(){
			return{
				placeholderStyle:{
					color:'#e7e7e7',
					fontSize:'40rpx'
				},
				phone:'',
				typeId:1,
				mobileType:[
					{id:1,title:'话费充值'},
					{id:2,title:'话费慢充'},
					{id:3,title:'流量充值'}
				],
				pricelist:[
					{
						id:1,
						price:10
					},{
						id:2,
						price:20
					},{
						id:3,
						price:30
					},{
						id:4,
						price:50
					},{
						id:5,
						price:100
					},{
						id:6,
						price:200
					},{
						id:7,
						price:300
					},{
						id:8,
						price:500
					},
				]
			}
		},
		methods:{
			clickMobileType(id){
				this.typeId = id
			}
		}
	}
</script>

<style lang="scss" scoped>
	.typeBottom{
		font-size: 32rpx;
		font-weight: bold;
		border-bottom: 4rpx solid #fc3f2d;
		// border-bottom-left-radius: 50%;
		// border-bottom-right-radius: 50%;
		padding-bottom: 5rpx;
		color: #fc3f2d;
	}
	.navIcon{
		// z-index: 999;
		position: fixed;
		right: 30rpx;
	}
	.mobileLogo{
		border-top: 1px solid #e7e7e7;
		padding-top: 10rpx;
		display: flex;
		justify-content: space-between;
		margin-bottom:50rpx;
	}
	.mobileImage{
		margin-left: 25rpx;
		width: 146rpx;
		height: 68rpx;
	}
	.mobileLogoLeft{
		display: flex;
	}
	.phonePrice{
		margin-left: 30rpx;
		margin-top: 14rpx;
	}
	.mobileLogoRight{
		display: flex;
		align-items: center;
	}
	.guanzhuNum{
		border-left: 4rpx solid #999;
		padding-left: 10rpx;
		font-size: 28rpx;
		width: 100rpx;
	}
	.guanzhu{
		display: flex;
		align-items: center;
		background-color: #fc3f2d;
		color: #fff;
		padding: 8rpx 16rpx;
		margin:0rpx 20rpx;
		border-radius: 28rpx;
	}
	.guanzhuIcon{
		transform: translate(-4rpx,3rpx);
	}
	.mobileTitle{
		border-bottom:2rpx solid #e7e7e7;
		padding-bottom: 10rpx;
		display: flex;
		justify-content: space-around;
	}
	.mobileTitleFont{
		font-size:30rpx;
		font-weight: bold;
	}
	.phoneInput{
		margin: 0 30rpx;
		text-indent: 1em;
		// font-size: 66rpx;
	}
	.priceBox{
		margin: 0 25rpx;
		display: flex;
		flex-wrap: wrap;
	}
	.priceItem{
		border: 1px solid #e7e7e7;
		width: 214rpx;
		height: 132rpx;
		line-height: 132rpx;
		margin: 10rpx;
		border-radius: 20rpx;
	}
	.priceItem:hover{
		border: 1px solid #fc3f2d;
	}
	.priceContent{
		display: flex;
		align-items: center;
		justify-content: center;
		color: #bfbfbf;
	}
	.priceContent:hover{
		color: #fc3f2d;
	}
	.priceItemMsg{
		font-weight: bold;
		font-size: 42rpx;
	}
	.priceYuan{
		font-size: 36rpx;
	}
	.btn{
		margin: 10rpx 25rpx;
	}
	.button{
		background-color: #fbbfb7;
		color: #fff;
		border-radius: 80rpx;
	}
	.button:hover{
		background-color:#fc3f2d ;
		color:#fc3f2d;
		color: #fff;
	}
	.footer{
		margin-top: 30rpx;
		text-align: center;
		color: #999;
	}
</style>
